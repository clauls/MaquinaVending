﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MáquinaVending
{
    internal class Producto
    {
        // Vamos a poner los atributos de esta clase
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int Unidades { get; set; }
        public double Precio { get; set; }
        public string Descripcion { get; set; }
        public Producto(int id) 
        {
            id = Id;
        }
        public Producto(int id, string nombre, int unidades, double precio, string descripcion)
        {
            Id = id;
            Nombre = nombre;
            Unidades = unidades;
            Precio = precio;
            Descripcion = descripcion;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine($"ID: {Id}");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Unidades disponibles: {Unidades}");
            Console.WriteLine($"Precio: {Precio}");
            Console.WriteLine($"Descripción: {Descripcion}");
        }
    }
}
