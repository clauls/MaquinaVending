﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MáquinaVending
{
    internal class MaquinaVending
    {
        List<Producto> productos;

        public MaquinaVending()
        {
            productos = new List<Producto>();
        }

        public void AddProducto(Producto producto)
        {
            productos.Add(producto);
        }

        public void MostrarProductosDisponibles()
        {
            foreach (Producto producto in productos)
            {
                producto.MostrarInformacion();
            }
        }
        public void ComprarProductos()
        {
            MostrarProductosDisponibles();
            Console.WriteLine("Introduzca el ID del producto que desee comprar:");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Desea elegir otro producto");
            string respuesta = Console.ReadLine().ToUpper();
            if(respuesta == "Y")
            {
                Console.WriteLine("Introduzca el ID del producto que desee comprar:");
                string id2 = Console.ReadLine();
            }else if(respuesta == "N")
            {
                Console.WriteLine("Introduzca su forma de pago: efectivo(E)/tarjeta(T)");
                string formapago = Console.ReadLine().ToUpper();
                if(formapago == "E")
                {
                    Producto p = new Producto(id);
                    PagarEfectivo(p);
                }
                else
                {
                    Producto p1 = new Producto(id);
                    PagarTarjeta(p1);
                }
            }

        }
        public void PagarEfectivo(Producto producto)
        {
            double totalpagado = 0;
            Console.WriteLine($"Precio total: {producto.Precio}");

            while(totalpagado > producto.Precio) 
            {
                Console.WriteLine("Introduzca moneda");
                double moneda = Convert.ToDouble(Console.ReadLine());
                totalpagado += moneda;
                Console.WriteLine($"Total pagado: {totalpagado}");
            }
            if(totalpagado >= producto.Precio) 
            {
                Console.WriteLine("Pago completado. Dispensando producto");
                producto.Unidades--;
            }
            else
            {
                Console.WriteLine("Pago insuficiente.Cancelando operacion");
            }
        }

        public void PagarTarjeta(Producto producto)
        {
            Console.WriteLine("Introduzca el numero de la tarjeta:");
            string cardNumber = Console.ReadLine();
            Console.WriteLine("Introduzca la fecha de expiración (MM/YY):");
            string fechaExpiracion = Console.ReadLine();
            Console.WriteLine("Introduzca el CVV");
            string CVV = Console.ReadLine();

            Console.WriteLine("Pago con tarjeta completado.Dispensando producto");
            producto.Unidades--;
        }
    }
}
